# Version 2020.1.0

- First official version as a package